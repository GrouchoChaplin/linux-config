# Split Rocky Linux Repo Utility

This package contains a Bash script to split a single combined `rocky8.repo`
into individual `.repo` files.

## Usage

```bash
chmod +x split_rocky8_repo.sh
./split_rocky8_repo.sh /path/to/rocky8.repo /path/to/output_dir
```

Example:
```bash
./split_rocky8_repo.sh /etc/yum.repos.d/rocky8.repo /etc/yum.repos.d/split
```

Each resulting `.repo` file will contain one repository section, e.g.:

```
Rocky-Baseos.repo
Rocky-Appstream.repo
Rocky-Extras.repo
Rocky-Powertools.repo
Rocky-Ha.repo
Rocky-Rs.repo
Rocky-Devel.repo
```
