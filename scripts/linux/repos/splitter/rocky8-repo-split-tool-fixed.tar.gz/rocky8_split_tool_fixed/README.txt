# Split Rocky Linux Repo Utility (Fixed Version)

This script correctly skips blank or commented lines before the first [repo] header
and prevents the AWK 'null string value' error.

## Usage

```bash
chmod +x split_rocky8_repo.sh
sudo bash ./split_rocky8_repo.sh /path/to/rocky8.repo /path/to/output_dir
```

Example:
```bash
sudo bash ./split_rocky8_repo.sh /etc/yum.repos.d/rocky8.repo /etc/yum.repos.d/split
```

Each resulting .repo file will contain one repository section.
