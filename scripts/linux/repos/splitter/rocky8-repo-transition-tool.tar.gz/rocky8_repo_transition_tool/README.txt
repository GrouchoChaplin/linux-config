# Rocky Linux Repo Transition Tool

This script transitions your system from a single combined `rocky8.repo`
to separate official-style `.repo` files.

## Usage

1. Extract this archive:
   ```bash
   tar -xvzf rocky8-repo-transition-tool.tar.gz
   cd rocky8_repo_transition_tool
   ```

2. Make the script executable:
   ```bash
   chmod +x transition_to_split_repos.sh
   ```

3. Run it (with sudo):
   ```bash
   sudo bash transition_to_split_repos.sh /etc/yum.repos.d/split
   ```

## What it does

- Backs up all current `.repo` files into `/etc/yum.repos.d/backup_<timestamp>`
- Moves your combined `rocky8.repo` to `rocky8.repo.disabled`
- Copies split `.repo` files into `/etc/yum.repos.d/`
- Cleans and rebuilds DNF metadata
- Shows active repositories at the end

This process is **safe** and **reversible**.
